// Indica el Nombre de Espacio
namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados                          
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            // Creamos los botones para las Monedas
            this.btn25Centavos = new System.Windows.Forms.Button();
            this.btn50Centavos = new System.Windows.Forms.Button();
            this.btn1Quetzal   = new System.Windows.Forms.Button();

            // Añade el Evento a cada boton
            this.btn25Centavos.Click +=btn25Centavos_Click;
            this.btn50Centavos.Click +=btn50Centavos_Click;
            this.btn1Quetzal.Click +=btn1Quetzal_Click;

            // Creamos la Etiqueta para el Total
            this.lblTotal   = new System.Windows.Forms.Label();

            // Define el Layout de la Forma
            this.SuspendLayout();
            
            // Establece caracteristicas de los Botones
            this.btn25Centavos.Location = new System.Drawing.Point(30, 30);
            this.btn25Centavos.Name = "btn25Centavos";
            this.btn25Centavos.Size = new System.Drawing.Size(75, 23);
            this.btn25Centavos.TabIndex = 0;
            this.btn25Centavos.Text = "25 Centavos";
            this.btn25Centavos.UseVisualStyleBackColor = true;

            this.btn50Centavos.Location = new System.Drawing.Point(130, 30);
            this.btn50Centavos.Name = "btn50Centavos";
            this.btn50Centavos.Size = new System.Drawing.Size(75, 23);
            this.btn50Centavos.TabIndex = 1;
            this.btn50Centavos.Text = "50 Centavos";
            this.btn50Centavos.UseVisualStyleBackColor = true;
            
            this.btn1Quetzal.Location = new System.Drawing.Point(230, 30);
            this.btn1Quetzal.Name = "btn1Quetzal";
            this.btn1Quetzal.Size = new System.Drawing.Size(75, 23);
            this.btn1Quetzal.TabIndex = 2;
            this.btn1Quetzal.Text = "1 Quetzal";
            this.btn1Quetzal.UseVisualStyleBackColor = true;

            // Caracteristicas la etiqueta
            this.lblTotal.Location = new System.Drawing.Point(30, 100);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(75, 23);
            this.lblTotal.TabIndex = 3;
            this.lblTotal.Text = "0.00";            

            // Crea el Formulario
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(350, 261);
            
            // Añade los 3 Botones
            this.Controls.Add(this.btn25Centavos);
            this.Controls.Add(this.btn50Centavos);
            this.Controls.Add(this.btn1Quetzal);
            this.Controls.Add(this.lblTotal);

            this.Name = "Form1";
            this.Text = "Maquina Despachadora de Agua";
            this.ResumeLayout(false);

        }

        #endregion
        
        // Se Definen las propiedades de la Forma
        private System.Windows.Forms.Button btn25Centavos;
        private System.Windows.Forms.Button btn50Centavos;
        private System.Windows.Forms.Button btn1Quetzal;
        private System.Windows.Forms.Label  lblTotal;        
    }
}