// --------------------------------------------------
// Tarea de C#
// Realizar un programa en su Lenguaje de Programacón
// de preferencia, que simula una máquina despachadora
// de bebidas de agua pura.
// La interfaz gráfica tendrá 3 botones; uno para simular
// la moneda de 25 centavos, otro para simular la moneda
// de 50 centanvos y la otra que simula la moneta de 1
// Quetzal. Cuando el usuario haga click en cualquiera
// de uno de los botones, ira sumando su cantidad corres
// pondiente. Cuando haya llegado a los 4 Quetzales o mas, 
// el programa mostrá un mensaje que diga:"Su botella de
// agua pura ha sido despachada", y deberá de ser capaz de
// de mostrar un mensaje con el cambio de la operación
// en caso de que el pago haya sido mayor.
// --------------------------------------------------------

// Librerias
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

// Nombre de Espacio Principal
namespace WindowsFormsApp1
{
    // Nombre de la Clase Principal
    static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]

        // Función Main
        static void Main()
        {
            // Prepara la aplicación
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Ejecuta la Aplicación creando un Objeto Form1
            Application.Run(new Form1());
        }
    }
}