// Librerías
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Nombre de Espacio
namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            // Inicializa los Componentes
            InitializeComponent();
        }
        private void btn25Centavos_Click(object sender, EventArgs e)
        {
            // Declaro variable para el total
            Double total;

            // Obtengo el total Actual y lo convierto
            total = Convert.ToDouble(lblTotal.Text);

            // Le Agrego 25 centavos
            total = total + .25;

            // Lo convierto a String y lo coloco en total
            lblTotal.Text = total.ToString();

            // Verifica si ya se ha llegado al Total
            if (total >=4)
            {
                // Despliega el Mensaje de Despacho
                MessageBox.Show("Su botella de agua pura ha sido despachada", "Sistema Despachador", MessageBoxButtons.OK);                        

                // Verifica si es mayor que 4
                if (total > 4)                
                {
                    // Calcula el Cambio
                    total = total - 4;

                    // Mensaje para recoger el Cambio
                    MessageBox.Show("Su Cambio es de:"+total.ToString(), "Sistema Despachador", MessageBoxButtons.OK);                        
                }
                // Inicializa el Total
                lblTotal.Text ="0.00";
            }            
        }

        private void btn50Centavos_Click(object sender, EventArgs e)
        {
            // Declaro variable para el total
            Double total;

            // Obtengo el total Actual y lo convierto
            total = Convert.ToDouble(lblTotal.Text);

            // Le Agrego 50 centavos
            total = total + .50;

            // Lo convierto a String y lo coloco en total
            lblTotal.Text = total.ToString();

            // Verifica si ya se ha llegado al Total
            if (total >=4)
            {
                // Despliega el Mensaje de Despacho
                MessageBox.Show("Su botella de agua pura ha sido despachada", "Sistema Despachador", MessageBoxButtons.OK);                        

                // Verifica si es mayor que 4
                if (total > 4)                
                {
                    // Calcula el Cambio
                    total = total - 4;

                    // Mensaje para recoger el Cambio
                    MessageBox.Show("Su Cambio es de:"+total.ToString(), "Sistema Despachador", MessageBoxButtons.OK);                        
                }
                // Inicializa el Total
                lblTotal.Text ="0.00";
            }            
        }

        private void btn1Quetzal_Click(object sender, EventArgs e)
        {
            // Declaro variable para el total
            Double total;

            // Obtengo el total Actual y lo convierto
            total = Convert.ToDouble(lblTotal.Text);

            // Le Agrego 1 Quetzal
            total = total + 1;

            // Lo convierto a String y lo coloco en total
            lblTotal.Text = total.ToString();

            // Verifica si ya se ha llegado al Total
            if (total >=4)
            {
                // Despliega el Mensaje de Despacho
                MessageBox.Show("Su botella de agua pura ha sido despachada", "Sistema Despachador", MessageBoxButtons.OK);                        

                // Verifica si es mayor que 4
                if (total > 4)                
                {
                    // Calcula el Cambio
                    total = total - 4;

                    // Mensaje para recoger el Cambio
                    MessageBox.Show("Su Cambio es de:"+total.ToString(), "Sistema Despachador", MessageBoxButtons.OK);                        
                }
                // Inicializa el Total
                lblTotal.Text ="0.00";
            }            
        }
    }
}





// Codigo de Consulta, no funciona
// //Text = button1.Text;
// Initializes the variables to pass to the MessageBox.Show method.
//string message = "Mensaje de Prueba";
//string caption = "Sistema";
//MessageBoxButtons buttons = MessageBoxButtons.OK;
//DialogResult result;
//lblTotal.Text ="10.00";
//message = lblTotal.Text;
// Displays the MessageBox.
//result = MessageBox.Show(message, caption, buttons);                       

// Get the control the Button control is located in. In this case a GroupBox.
//Control control = btn25Centavos.Parent;
// Set the text and backcolor of the parent control.
//control.Text = "My Groupbox";
//control.BackColor = Color.Blue;
// Get the form that the Button control is contained within.
//Form myForm = btn25Centavos.FindForm();
// Set the text and color of the form containing the Button.
//myForm.Text = "The Form of My Control";
//myForm.BackColor = Color.Red;